
<?php  include 'top.html';
session_start();
if (!empty($_SESSION['username']))
$con2=mysqli_connect('localhost','root','','thebigsecond');
$sql2 = "select * from users where username like '$_SESSION[username]' and password like '$_SESSION[password]'";
$exe2=mysqli_query($con2,$sql2);
$r2 = mysqli_fetch_array($exe2);
mysqli_close($con2);
if ($r2['user_type'] != 1){
    header("location:error.html");
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name ="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<h1>weapons</h1>
        <form action='asweapon_register.php'>
            <label>user (follows the order of the hq renders (agents first))</label>
            <input type='text' name='id_chara'><br>
            <label>weapon name</label>
            <input type='text'name='weapon_name'><br> 
            <label>damage per second</label>
            <input type='text'name='weapon_dps'><br>
            <label>rounds per minute</label>
            <input type='text'name='weapon_rpm'><br>
            <label>maximum ammo</label>
            <input type='text'name='weapon_maxammo'><br> 
            <label>reserve ammo</label>
            <input type='text'name='weapon_reserveammo'><br> 
            <label>damage</label>
            <input type='text'name='weapon_dmg'><br> 
            <label>headshot damage</label>
            <input type='text'name='weapon_headshot'><br> 
            <label>accuracy</label>
            <input type='text'name='weapon_accuracy'><br> 
            <label>description</label>
            <input type='text'name='weapon_desc'><br> 
            <label>hp, (0 if none)</label>
            <input type='text'name='weapon_hp'><br>
            <input type='submit' value='ver resullpwatod'>      
        </form>
</html>
   <?php
    include 'bottom.html'
    ?>
