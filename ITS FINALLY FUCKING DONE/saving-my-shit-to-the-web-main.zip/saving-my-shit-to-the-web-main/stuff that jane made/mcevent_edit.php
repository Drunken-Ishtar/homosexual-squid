<?php  include 'top.html';
session_start();
if (!empty($_SESSION['username']))
$con2=mysqli_connect('localhost','root','','thebigsecond');
$sql2 = "select * from users where username like '$_SESSION[username]' and password like '$_SESSION[password]'";
$exe2=mysqli_query($con2,$sql2);
$r2 = mysqli_fetch_array($exe2);
mysqli_close($con2);
if ($r2['user_type'] != 1){
    header("location:error.html");
}
$con=mysqli_connect('localhost','root','','thebigsecond');
$id_mctype = $_GET['id_mctype'];
$sql = "select * from mc_eventtype where id_mctype=$id_mctype";
$exe = mysqli_query($con, $sql);
$r = mysqli_fetch_array($exe);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name ="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <form action='mcevent_edit2.php'>
        <label>id</label>
        <input readonly type='text'name='id_mctype' value=<?php echo $r['id_mctype']; ?>><br>
        <label>name</label>
        <input type='text'name='mctype_name' value=<?php echo $r['mctype_name']; ?>><br>
        
        
        <input type='submit' value='ver resullpwatod'>
</html>
   <?php
    include 'bottom.html'
    ?>
