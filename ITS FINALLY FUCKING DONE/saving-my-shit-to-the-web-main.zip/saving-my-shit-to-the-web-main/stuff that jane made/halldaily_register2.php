<?php include 'top.html'
?>
<?php 
$mchalldaily_date = $_GET['mchalldaily_date'];
$mchalldaily_desc= $_GET['mchalldaily_desc'];
$con=mysqli_connect('localhost','root','','thebigsecond');
$sql = "insert into mc_halloweendaily (mchalldaily_date,mchalldaily_desc)
 values('$mchalldaily_date', '$mchalldaily_desc')";         
$exe = mysqli_query($con, $sql);
echo"$sql";
if ($exe){
    echo"it worked, go back <a href='halldaily.php'>halloweiner daily challenges</a>";
}
else{
    echo"1x1x1x1 done fucked something up";
}

$fecha=mysqli_close($con);
?>
<?php include 'bottom.html'
?>
