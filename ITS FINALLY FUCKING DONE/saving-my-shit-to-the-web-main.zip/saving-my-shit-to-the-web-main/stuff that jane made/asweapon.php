<?php include 'top.html'
?>
<?php
$con = mysqli_connect('localhost','root','','thebigsecond');
$sql = "select * from as_weapon order by id_weapon ASC";
$exe = mysqli_query($con, $sql);
echo"<a href='asweaponcreate.php'>add a gun</a><br>";
while ($res = mysqli_fetch_array ($exe)){
    $id_weapon = $res['id_weapon'];
    $id_chara = $res['id_chara'];
    $weapon_name = $res['weapon_name'];
    $weapon_rpm = $res['weapon_rpm'];
    $weapon_dps = $res['weapon_dps'];
    $weapon_maxammo = $res['weapon_maxammo'];
    $weapon_reserveammo = $res['weapon_reserveammo'];
    $weapon_dmg = $res['weapon_dmg'];
    $weapon_headshot = $res['weapon_headshot'];
    $weapon_accuracy = $res['weapon_accuracy'];
    $weapon_desc = $res['weapon_desc'];
    $weapon_hp = $res['weapon_hp'];
    echo"id = $id_weapon, character=$id_chara, name=$weapon_name, rounds per minute=$weapon_rpm, damage per second=$weapon_dps,
    max ammo=$weapon_maxammo, reserve ammo=$weapon_reserveammo, damage=$weapon_dmg, headshot damage=$weapon_headshot,
    accuracy=$weapon_accuracy, description=$weapon_desc, health(0 if doesnt have any)=$weapon_hp";
    echo"<a href='asweapon_remover.php?id_weapon=$id_weapon'>remove</a>|<a href='asweapon_edit.php?id_weapon=$id_weapon'>edit</a><br>";
    }
?>
<?php include 'bottom.html'
?>