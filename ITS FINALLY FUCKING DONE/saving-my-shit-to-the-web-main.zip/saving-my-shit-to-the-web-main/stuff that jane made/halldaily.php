<?php include 'top.html';
session_start();
  if(empty($_SESSION['username'])) {
        header('location:login.php');
    };
?>
<?php
$con = mysqli_connect('localhost','root','','thebigsecond');
$sql = "select * from mc_halloweendaily order by id_mchalldaily ASC";
$exe = mysqli_query($con, $sql);
echo"<a href='halldaily_register.php'>add a new halloween daily challenge</a><br>";
while ($res = mysqli_fetch_array ($exe)){
    $id_mchalldaily = $res['id_mchalldaily'];
    $mchalldaily_date = $res['mchalldaily_date'];
    $mchalldaily_desc = $res['mchalldaily_desc'];

    echo"id = $id_mchalldaily, challenge date=$mchalldaily_date, description=$mchalldaily_desc";
    echo"<a href='halldaily_remover.php?id_mchalldaily=$id_mchalldaily'>remove</a>
    |<a href='halldaily_edit.php?id_mchalldaily=$id_mchalldaily'>edit</a><br>";
    }
?>
<?php include 'bottom.html'
?>