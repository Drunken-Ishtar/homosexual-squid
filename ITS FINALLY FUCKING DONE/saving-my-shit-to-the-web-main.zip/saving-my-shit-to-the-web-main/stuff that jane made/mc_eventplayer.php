<?php include 'top.html'
?>
<?php
$con = mysqli_connect('localhost','root','','thebigsecond');
$sql = "select * from mc_event_player order by id_mcevent ASC";
$exe = mysqli_query($con, $sql);
echo"<a href='eventplayer_create.php'>add an event</a><br>";
while ($res = mysqli_fetch_array ($exe)){
    $id_eventplayer = $res['id_eventplayer'];
    $id_mcevent = $res['id_mcevent'];
    echo" event id=$id_mcevent, playerid = $id_eventplayer, coin amount=$halloween_coins, bulbs amount=$xmas_bulbs";
    echo"<a href='mcevent_remover.php?id_eventplayer=$id_eventplayer'>remove</a>|<a href='mcevent_edit.php?id_eventplayer=$id_eventplayer'>edit</a><br>";
    }
?>
<?php include 'bottom.html'
?>