<?php include 'top.html'
?>
<?php 
$mchallpower_name = $_GET['mchallpower_name'];
$mchallpower_owner= $_GET['mchallpower_owner'];
$mchallpower_desc = $_GET['mchallpower_desc'];
$con=mysqli_connect('localhost','root','','thebigsecond');
$sql = "insert into mc_halloweenpowers (mchallpower_name,mchallpower_owner,mchallpower_desc)
 values('$mchallpower_name', '$mchallpower_owner', '$mchallpower_desc')";         
$exe = mysqli_query($con, $sql);
echo"$sql";
if ($exe){
    echo"it worked, go back <a href='hallpowers.php'>halloweiner powaas</a>";
}
else{
    echo"1x1x1x1 done fucked something up";
}

$fecha=mysqli_close($con);
?>
<?php include 'bottom.html'
?>
