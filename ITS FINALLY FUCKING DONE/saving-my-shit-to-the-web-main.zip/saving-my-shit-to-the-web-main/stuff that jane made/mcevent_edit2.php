<?php include 'top.html'
?>
<?php 
$id_mcevent = $_GET['id_mcevent'];
$mcevent_name = $_GET['mcevent_name'];
$mcevent_desc = $_GET['mcevent_desc'];
$mcevent_type = $_GET['mcevent_type'];
$mcevent_start = $_GET['mcevent_start'];
$mcevent_end = $_GET['mcevent_end'];
$con=mysqli_connect('localhost','root','','thebigsecond');
$sql = "update mc_events set mcevent_name = '$mcevent_name',mcevent_desc = '$mcevent_desc',mcevent_type = '$mcevent_type',mcevent_start = '$mcevent_start',
mcevent_end = '$mcevent_end'where id_mcevent=$id_mcevent";         
$exe = mysqli_query($con, $sql);
if ($exe){
    echo"it worked, go back <a href='mcevent.php'>mcevent</a>";
}
else{
    echo"1x1x1x1 done fucked something up";
}

$fecha=mysqli_close($con);
?>
<?php include 'bottom.html'
?>
