<?php
$maxcount = 1000000;

$count = 50;
while ($count > 1){
$rando =rand(0,$maxcount);
$minmincunt = $rando / 1.1;
$rando2 = rand($minmincunt,$rando);
echo "start anew, (endgoal is $rando2)<br>";

while ($rando > $rando2){
echo "$rando<br>";
$rando --;}$count --;$maxcount = $maxcount-1;}


?>