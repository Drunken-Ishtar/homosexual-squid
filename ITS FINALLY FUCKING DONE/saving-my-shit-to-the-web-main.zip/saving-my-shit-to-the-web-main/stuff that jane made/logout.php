<?php  include 'top.html';
session_start();


session_destroy();
?>