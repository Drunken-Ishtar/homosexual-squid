<?php include 'top.html'
?>
<?php
$con = mysqli_connect('localhost','root','','thebigsecond');
$sql = "select * from as_tournament order by id_astournament ASC";
$exe = mysqli_query($con, $sql);
echo"<a href='astournament_create.php'>register a tournament</a><br>";
while ($res = mysqli_fetch_array ($exe)){
    $id_astournament = $res['id_astournament'];
    $astournament_map = $res['astournament_map'];
    $astournament_desc = $res['astournament_desc'];
    $astournament_patch = $res['astournament_patch'];
    $astournament_start = $res['astournament_start'];
    $astournament_end = $res['astournament_end'];
    echo"id = $id_astournament, map=$astournament_map tournament description=$astournament_desc tournament patch=$astournament_patch start date=$astournament_start end date=$astournament_end";
    echo"<a href='astournament_remover.php?id_astournament=$id_astournament'>remove</a>|<a href='astournament_edit.php?id_astournament=$id_astournament'>edit</a><br>";
    }
?>
<?php include 'bottom.html'?>