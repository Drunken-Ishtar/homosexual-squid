<?php  include 'top.html';

    echo"im only gonna put 2 database here to Crud just to see if it will work<br>";
    echo"<a href='aschar.php'>ascharacter</a><br>";
    echo"<a href='asmap.php'>asmaps</a><br>";
    echo"<a href='mcevent.php'>minevents</a><br>";
    echo"<a href='mceventtype.php'>minetypes</a><br>";
    echo"<a href='asteam.php'>asteam</a><br>";
    echo"<a href='aspatchnotes.php'>patchnotes</a><br>";
    echo"<a href='astournament.php'>tournaments stuff</a><br>";
    echo"<a href='asweapon.php'>weapons</a><br>";
    echo"<a href='hallhouses.php'>haloweiner</a><br>";
    echo"<a href='hallpowers.php'>halopeener</a><br>";
    echo"<a href='halldaily.php'>halogooner</a><br>";

include 'bottom.html'
?>