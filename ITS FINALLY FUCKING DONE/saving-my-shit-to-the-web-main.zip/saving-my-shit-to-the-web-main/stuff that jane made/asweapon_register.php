<?php include 'top.html'
?>
<?php 
$id_chara = $_GET['id_chara'];
$weapon_name = $_GET['weapon_name'];
$weapon_rpm = $_GET['weapon_rpm'];
$weapon_dps = $_GET['weapon_dps'];
$weapon_maxammo = $_GET['weapon_maxammo'];
$weapon_reserveammo = $_GET['weapon_reserveammo'];
$weapon_dmg = $_GET['weapon_dmg'];
$weapon_headshot = $_GET['weapon_headshot'];
$weapon_accuracy = $_GET['weapon_accuracy'];
$weapon_desc = $_GET['weapon_desc'];
$weapon_hp = $_GET['weapon_hp'];
$con=mysqli_connect('localhost','root','','thebigsecond');
$sql = "insert into as_weapon (id_chara,weapon_name,weapon_rpm,weapon_dps,weapon_maxammo,weapon_reserveammo,weapon_dmg,
weapon_headshot,weapon_accuracy,weapon_desc,weapon_hp) values('$id_chara', '$weapon_name', '$weapon_rpm', '$weapon_dps',
'$weapon_maxammo', '$weapon_reserveammo' '$weapon_dmg', '$weapon_headshot', '$weapon_accuracy', '$weapon_desc',
'$weapon_hp'),";

$exe = mysqli_query($con, $sql);
echo"$sql";
if ($exe){
    echo"it worked, go back <a href='astournament.php'>tournaments</a>";
}
else{
    echo"1x1x1x1 done fucked something up";
}

$fecha=mysqli_close($con);
?>
<?php include 'bottom.html'
?>
