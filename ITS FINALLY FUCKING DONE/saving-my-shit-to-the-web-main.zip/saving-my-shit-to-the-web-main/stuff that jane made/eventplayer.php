<?php include 'top.html'
?>
<?php
$con = mysqli_connect('localhost','root','','thebigsecond');
$sql = "select * from eventplayer order by id_eventplayer ASC";
$exe = mysqli_query($con, $sql);
echo"<a href='eventplayer_create.php'>add an event</a><br>";
while ($res = mysqli_fetch_array ($exe)){
    $id_eventplayer = $res['id_eventplayer'];
    $halloween_candy = $res['halloween_candy'];
    $halloween_coins = $res['halloween_coins'];
    $xmas_bulbs = $res['xmas_bulbs'];
    echo"id = $id_eventplayer, candy amount=$halloween_candy, coin amount=$halloween_coins, bulbs amount=$xmas_bulbs";
    echo"<a href='mcevent_remover.php?id_eventplayer=$id_eventplayer'>remove</a>|<a href='mcevent_edit.php?id_eventplayer=$id_eventplayer'>edit</a><br>";
    }
?>
<?php include 'bottom.html'
?>