<?php include 'top.html'
?>
<?php
$con = mysqli_connect('localhost','root','','thebigsecond');
$sql = "select * from as_patchnotes order by id_asnote ASC";
$exe = mysqli_query($con, $sql);
echo"<a href='aspatchnote_create.php'>add a patchnote</a><br>";
while ($res = mysqli_fetch_array ($exe)){
    $id_asnote = $res['id_asnote'];
    $asnote_name = $res['asnote_name'];
    $asnote_note = $res['asnote_note'];
    echo"id = $id_asnote, name=$asnote_name patchnote=$asnote_note";
    echo"<a href='aspatchnote_remover.php?id_asnote=$id_asnote'>remove</a>|<a href='aspatchnote_edit.php?id_asnote=$id_asnote'>edit</a><br>";
    }
?>
<?php include 'bottom.html'?>