<?php  include 'top.html';
session_start();

    if(empty($_SESSION['username'])) {
        header('location:login.php');
    };
    
if (!empty($_SESSION['username']))
$con2=mysqli_connect('localhost','root','','thebigsecond');
$sql2 = "select * from users where username like '$_SESSION[username]' and password like '$_SESSION[password]'";
$exe2=mysqli_query($con2,$sql2);
$r2 = mysqli_fetch_array($exe2);
mysqli_close($con2);
if ($r2['user_type'] != 1){
    header("location:error.html");
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name ="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<h1>tournament stuff    <form action='astournament_register.php'>
            map <select name="tournament_map">
            <?php 
                $sql1 = "SELECT * FROM as_mappool order by id_map asc";
                $con=mysqli_connect('localhost','root','','thebigsecond');
                $exe1 = mysqli_query($con, $sql1);
                $r = mysqli_fetch_array($exe);
                while($r = mysqli_fetch_array($exe1)){
                    $id_mappool = $r['id_mappool'];
                    $id_map = $r['id_map'];
                    if($r['tournament_map'] == $id_mappool){
                        $aux = "selected";
                    }
                    else{
                        $aux = "";
                    }
                    echo "<option $aux value='$id_mappool'>$id_map</option><br>";
                }
            ?>
            <h3>tournament_description</h3>
            <input type='text' name='astournament_desc'><br>
            <label>tournament_patchnotes</label>
            <input type='text' name='astournament_patch'><br>
            <label>tournament_start date</label>
            <input type='date' name='astournament_start'><br>
            <label>tournament end date</label>
            <input type='date' name='astournament_end'><br>
            <input type='submit' value='add player to team'>      
        </form>
</html>
   <?php
    include 'bottom.html'
    ?>
