<?php include 'top.html'
?>
<?php
    $con = mysqli_connect('localhost','root','','thebigsecond');
    $id_mcevent = $_GET['id_mcevent'];
    $sql="delete from mc_events where id_mcevent=$id_mcevent";
    $exe = mysqli_query($con, $sql);
if ($exe){
    echo"works :), go back <a href='mcevent.php'>as_character</a>";
}
else{
    echo"1x1x1x1 done fucked something up";
}
$fecha=mysqli_close($con);
?>
<?php include 'bottom.html'
?>