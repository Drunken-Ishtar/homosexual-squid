<?php include 'top.html'
?>
<?php 
$astournament_map = $_GET['astournament_map'];
$astournament_desc= $_GET['astournament_desc'];
$astournament_patch = $_GET['astournament_patch'];
$astournament_start = $_GET['astournament_start'];
$astournament_end = $_GET['astournament_end'];
$con=mysqli_connect('localhost','root','','thebigsecond');
$sql = "insert into as_tournament (astournament_map,astournament_desc,astournament_patch,astournament_start,astournament_end) values('$astournament_map', '$astournament_desc', '$astournament_patch', '$astournament_start', '$astournament_end')";         
$exe = mysqli_query($con, $sql);
echo"$sql";
if ($exe){
    echo"it worked, go back <a href='astournament.php'>tournaments</a>";
}
else{
    echo"1x1x1x1 done fucked something up";
}

$fecha=mysqli_close($con);
?>
<?php include 'bottom.html'
?>
