<?php include 'top.html'
?>
<?php
    $con = mysqli_connect('localhost','root','','thebigsecond');
    $id_mctype = $_GET['id_mctype'];
    $sql="delete from mc_eventtype where id_mctype=$id_mctype";
    $exe = mysqli_query($con, $sql);
if ($exe){
    echo"works :), go back <a href='mceventtype.php'>type</a>";
}
else{
    echo"1x1x1x1 done fucked something up";
}
$fecha=mysqli_close($con);
?>
<?php include 'bottom.html'
?>