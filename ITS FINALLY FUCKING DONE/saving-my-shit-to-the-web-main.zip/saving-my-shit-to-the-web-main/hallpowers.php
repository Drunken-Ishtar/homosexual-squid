<?php include 'top.html';
session_start();
  if(empty($_SESSION['username'])) {
        header('location:login.php');
    };
?>
(  .  )(  .  ) 
<?php
$con = mysqli_connect('localhost','r oot','','thebigsecond');
$sql = "select * from mc_hallpowers order by mchallpower_name ASC";
$exe = mysqli_query($con, $sql);
echo"<a href='hallpower_register.php'>add a new halloween house</a><br>";
while ($res = mysqli_fetch_array ($exe)){
    $id_mchallpower = $res['id_mchallpower'];
    $mchallpower_name = $res['mchallpower_name'];
    $mchallpower_owner = $res['mchallpower_owner'];
    $mchallpower_desc = $res['mchallpower_desc'];

    echo"id = $id_mchallpower, power name=$mchallpower_name, mchallpower_desc=$mchallpower_desc,
     mchallpower_owner=$mchallpower_owner";
    echo"<a href='hallhouse_remover.php?id_mchallhouse=$id_mchallhouse'>remove</a>
    |<a href='hallhouse_edit.php?id_mchallhouse=$id_mchallhouse'>edit</a><br>";
    }
?>
<?php include 'bottom.html'
?>