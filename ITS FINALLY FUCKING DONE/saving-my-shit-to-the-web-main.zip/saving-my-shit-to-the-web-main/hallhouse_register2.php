<?php include 'top.html'
?>
<?php 
$mchallhouse_name = $_GET['mchallhouse_name'];
$mchallhouse_creator= $_GET['mchallhouse_creator'];
$mchallhouse_minigame = $_GET['mchallhouse_minigame'];
$con=mysqli_connect('localhost','root','','thebigsecond');
$sql = "insert into mc_hallhouses (mchallhouse_name,mchallhouse_creator,mchallhouse_minigame)
 values('$mchallhouse_name', '$mchallhouse_creator', '$mchallhouse_minigame')";         
$exe = mysqli_query($con, $sql);
echo"$sql";
if ($exe){
    echo"it worked, go back <a href='hallhouses.php'>halloweiner houses</a>";
}
else{
    echo"1x1x1x1 done fucked something up";
}

$fecha=mysqli_close($con);
?>
<?php include 'bottom.html'
?>
