<?php include 'top.html';
session_start();
  if(empty($_SESSION['username'])) {
        header('location:login.php');
    };
?>

<?php
$con = mysqli_connect('localhost','root','','thebigsecond');
$sql = "select * from mc_hallhouses order by mchallhouse_name ASC";
$exe = mysqli_query($con, $sql);
echo"<a href='hallhouse_register.php'>add a new halloween house</a><br>";
while ($res = mysqli_fetch_array ($exe)){
    $id_mchallhouse = $res['id_mchallhouse'];
    $mchallhouse_name = $res['mchallhouse_name'];
    $mchallhouse_creator = $res['mchallhouse_creator'];
    $mchallhouse_minigame = $res['mchallhouse_minigame'];

    echo"id = $id_mchallhouse, house name=$mchallhouse_name, creator=$mchallhouse_creator, minigame=$mchallhouse_minigame";
    echo"<a href='hallhouse_remover.php?id_mchallhouse=$id_mchallhouse'>remove</a>
    |<a href='hallhouse_edit.php?id_mchallhouse=$id_mchallhouse'>edit</a><br>";
    }
?>
<?php include 'bottom.html'
?>